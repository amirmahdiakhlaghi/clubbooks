<?php return array (
  'article.article' => 'App\\Http\\Livewire\\Article\\Article',
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'auth.register' => 'App\\Http\\Livewire\\Auth\\Register',
  'book.book' => 'App\\Http\\Livewire\\Book\\Book',
  'book.books' => 'App\\Http\\Livewire\\Book\\Books',
  'footer' => 'App\\Http\\Livewire\\Footer',
  'header' => 'App\\Http\\Livewire\\Header',
  'index.article-card' => 'App\\Http\\Livewire\\Index\\ArticleCard',
  'index.book-card' => 'App\\Http\\Livewire\\Index\\BookCard',
  'index.index' => 'App\\Http\\Livewire\\Index\\Index',
);
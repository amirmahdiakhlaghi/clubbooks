require('./bootstrap');
var turbolinks = require("turbolinks")
turbolinks.start();
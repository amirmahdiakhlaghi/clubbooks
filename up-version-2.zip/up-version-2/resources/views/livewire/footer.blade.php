<footer class="container-fluid bg-dark text-light p-3 p-md-4 w-100vw m-0">
      <div class="row">
        <div class="col-11 col-md-4">
          <h5 class="text-center">عنوان</h5>
          <p class="text-justify font_0_9">توضیحاتی در فوتر توضیحاتی در فوتر توضیحاتی در فوتر توضیحاتی در فوترتوضیحاتی در فوترتوضیحاتی در فوتر توضیحاتی در فوتر </p>
        </div>

        <div class="col-11 col-md-4">
          <h5 class="text-center">عنوان</h5>
         <ul class="px-0">
           <li class="text-center"><a href="#">اپلیکیشن</a></li>
           <li class="text-center"><a href="#">تماس با ما</a></li>
           <li class="text-center"><a href="#">قوانین</a></li>
           <li class="text-center"><a href="#">پرسش های متدوال</a></li>
           <li class="text-center"><a href="#">به ما بپیوندید</a></li>
         </ul>
        </div>

        <div class="col-11 col-md-4">
          <h5 class="text-center">عنوان</h5>
         <ul class="px-0">
          <li class="text-center"><a href="#">لینک 1</a></li>
          <li class="text-center"><a href="#">لینک 2</a></li>
          <li class="text-center"><a href="#">لینک 3</a></li>
          <li class="text-center"><a href="#">لینک 4</a></li>
          <li class="text-center"><a href="#">لینک 5</a></li>
         </ul>
        </div>

      </div>

      <hr class="bg-light col-11">

      <div class="d-flex justify-content-center align-items-center">
        <i class="fab fa-2x cursor_pointer fa-instagram px-2 mx-2"></i>
        <i class="fab fa-2x cursor_pointer fa-telegram px-2 mx-2"></i>
        <i class="fab fa-2x cursor_pointer fa-facebook px-2 mx-2"></i>
      </div>

</footer>

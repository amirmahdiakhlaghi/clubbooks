<?php

namespace App\Http\Livewire\Book;

use App\Models\Book as ModelsBook;
use Livewire\Component;

class Book extends Component
{
    public $book;
    public function mount($slug){
        $book = ModelsBook::where('slug', $slug)->get()->first();
        $this->book = $book;
    }

    public function render()
    {
        return view('livewire.book.book');
    }
}
